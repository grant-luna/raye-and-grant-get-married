"use client";

import Image from "next/image";
import Container from "react-bootstrap/Container";
import Link from "next/link";

export default function Page() {
  return (
    <main
      style={{
        minHeight: "100svh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <Container fluid style={{ padding: 0 }}>
        <div
          style={{
            minHeight: "100svh",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: "30px 18px 34px",
          }}
        >
          <div
            style={{
              width: "100%",
              maxWidth: 1080,
              textAlign: "center",
              color: "#544f44",
            }}
          >
            <p
              className="font-subheader"
              style={{
                fontSize: "clamp(18px, 1.8vw, 21px)",
                marginBottom: 40,
                letterSpacing: "0.11em",
                color: "#5b554d",
              }}
            >
              Welcome to our Wedding Website!
            </p>

            <h1
              className="font-header"
              style={{
                fontSize: "clamp(56px, 6vw, 60px)",
                lineHeight: 0.95,
                marginBottom: 20,
                color: "#9a6677",
              }}
            >
              Raye &amp; Grant
            </h1>

            <div
              className="font-subheader"
              style={{
                fontSize: "clamp(22px, 2vw, 24px)",
                letterSpacing: "0.05em",
                color: "#b04a78",
                textTransform: "none",
                marginBottom: 0,
              }}
            >
              August 22nd, 2026
            </div>

            <div
              style={{
                position: "relative",
                width: "100%",
                maxWidth: 980,
                margin: "0 auto",
                aspectRatio: "16 / 8.2",
                marginTop: -50,
                marginBottom: -6,
              }}
            >
              <Image
                src="/expanded venue 2.png"
                alt="Wedding venue illustration"
                fill
                priority
                style={{
                  objectFit: "contain",
                  objectPosition: "center top",
                }}
              />
            </div>

            <div
              style={{
                position: "relative",
                zIndex: 2,
                marginTop: -150,
                marginBottom: 28,
              }}
            >
              <Link href="/rsvp" className="hero-rsvp-pill">
                Submit your RSVP
              </Link>
            </div>

            <div
              style={{
                maxWidth: 900,
                margin: "0 auto",
                padding: "0 10px",
              }}
            >
              <p
                style={{
                  fontSize: "clamp(18px, 1.7vw, 21px)",
                  lineHeight: 1.5,
                  marginBottom: 8,
                  color: "#9b9388",
                  fontStyle: "italic",
                  letterSpacing: "0.03em",

                }}
              >
                This site has everything you’ll need for the weekend, including
                event details, travel information, and RSVP&apos;s. Please check back in as we get closer to the date for more
                information about the weekend.
              </p>

              <p
                style={{
                  fontSize: "clamp(18px, 1.7vw, 21px)",
                  lineHeight: 1.95,
                  marginBottom: 8,
                  color: "#9b9388",
                  fontStyle: "italic",
                                    letterSpacing: "0.03em",

                }}
              >
                We can’t wait to see you!
              </p>
            </div>
          </div>
        </div>
      </Container>

      <style jsx global>{`
        .hero-rsvp-pill {
          display: inline-block;
          background-color: #b0065d;
          color: #f8eef3;
          text-decoration: none;
          padding: 9px 40px 10px;
          border-radius: 10px;
          font-family: var(--font-subheader);
          font-weight: 600;
          font-size: clamp(18px, 1.6vw, 21px);
          letter-spacing: 0.03em;
          text-transform: none;
          box-shadow: 0 4px 10px rgba(0, 0, 0, 0.08);
          transition: transform 0.2s ease, opacity 0.2s ease;
        }

        .hero-rsvp-pill:hover {
          transform: scale(1.04);
          opacity: 0.94;
        }

        .hero-rsvp-pill:active {
          transform: scale(1.06);
        }

        @media (max-width: 768px) {
          .hero-rsvp-pill {
            padding: 11px 24px 12px;
            font-size: 18px;
          }
        }
      `}</style>
    </main>
  );
}